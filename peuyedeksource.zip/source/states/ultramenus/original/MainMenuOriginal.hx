package states.ultramenus.original;

import flixel.FlxG;
import flixel.FlxObject;
import flixel.FlxSprite;
import flixel.effects.FlxFlicker;
import flixel.group.FlxGroup;
import flixel.group.FlxSpriteGroup;
import flixel.math.FlxMath;
import flixel.text.FlxText;
import flixel.tweens.FlxTween;
import flixel.tweens.FlxEase;
import flixel.util.FlxColor;
import lime.app.Application;
import states.editors.MasterEditorMenu;
import options.OptionsState;
import backend.ThemeManager;
import backend.WorkspaceSwitcher;
import backend.MusicPlayer;
import backend.widgets.WidgetBase;
import backend.widgets.WidgetManager;
import backend.widgets.WidgetShop;

enum MainMenuColumn {
    LEFT;
    CENTER;
    RIGHT;
}

class MainMenuOriginal extends MusicBeatState
{
    public static var psychEngineVersion:String = '1.0.4';
    public static var curSelected:Int = 0;
    public static var curColumn:MainMenuColumn = CENTER;
    var allowMouse:Bool = true;

    var menuItems:FlxTypedGroup<FlxSprite>;
    var leftItem:FlxSprite;
    var rightItem:FlxSprite;

    var optionShit:Array<String> = [
        'story_mode',
        'freeplay',
        #if MODS_ALLOWED 'mods', #end
        'credits'
    ];

    var leftOption:String = #if ACHIEVEMENTS_ALLOWED 'achievements' #else null #end;
    var rightOption:String = 'options';

    var magenta:FlxSprite;
    var camFollow:FlxObject;

    // Widget sistemi
    var widgetManager:WidgetManager;
    var widgetContainer:FlxSpriteGroup;
    var widgetShop:WidgetShop;
    
    // Music Player
    var musicPlayer:MusicPlayer;

    // Eksik değişkenler
    var selectedSomethin:Bool = false;
    var timeNotMoving:Float = 0;

    static var showOutdatedWarning:Bool = true;

    override function create()
    {
        super.create();

        #if MODS_ALLOWED
        Mods.pushGlobalMods();
        #end
        Mods.loadTopMod();

        #if DISCORD_ALLOWED
        DiscordClient.changePresence("In the Menus", null);
        #end

        persistentUpdate = persistentDraw = true;

        WorkspaceSwitcher.init();

        var yScroll:Float = 0.25;
        var bg:FlxSprite = new FlxSprite(-80).loadGraphic(Paths.image('menuBG'));
        bg.antialiasing = ClientPrefs.data.antialiasing;
        bg.scrollFactor.set(0, yScroll);
        bg.setGraphicSize(Std.int(bg.width * 1.175));
        bg.updateHitbox();
        bg.screenCenter();
        add(bg);

        camFollow = new FlxObject(0, 0, 1, 1);
        add(camFollow);

        magenta = new FlxSprite(-80).loadGraphic(Paths.image('menuDesat'));
        magenta.antialiasing = ClientPrefs.data.antialiasing;
        magenta.scrollFactor.set(0, yScroll);
        magenta.setGraphicSize(Std.int(magenta.width * 1.175));
        magenta.updateHitbox();
        magenta.screenCenter();
        magenta.visible = false;
        magenta.color = 0xFFfd719b;
        add(magenta);

        menuItems = new FlxTypedGroup<FlxSprite>();
        add(menuItems);

        for (num => option in optionShit)
        {
            var item:FlxSprite = createMenuItem(option, 0, (num * 140) + 90);
            item.y += (4 - optionShit.length) * 70;
            item.screenCenter(X);
        }

        if (leftOption != null)
            leftItem = createMenuItem(leftOption, 60, 490);
        if (rightOption != null)
        {
            rightItem = createMenuItem(rightOption, FlxG.width - 60, 490);
            rightItem.x -= rightItem.width;
        }

        var psychVer:FlxText = new FlxText(12, FlxG.height - 44, 0, "Psych Engine v" + psychEngineVersion, 12);
        psychVer.scrollFactor.set();
        psychVer.setFormat(Paths.font("vcr.ttf"), 16, FlxColor.WHITE, LEFT, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
        add(psychVer);

        var fnfVer:FlxText = new FlxText(12, FlxG.height - 24, 0, "Friday Night Funkin' v" + Application.current.meta.get('version'), 12);
        fnfVer.scrollFactor.set();
        fnfVer.setFormat(Paths.font("vcr.ttf"), 16, FlxColor.WHITE, LEFT, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
        add(fnfVer);

        var wsHint:FlxText = new FlxText(FlxG.width - 220, FlxG.height - 30, 200, "SHIFT → Workspace", 14);
        wsHint.scrollFactor.set();
        wsHint.setFormat(Paths.font("vcr.ttf"), 14, 0xFF888888, RIGHT);
        add(wsHint);
		
		var widgetCam = new FlxCamera();
		widgetCam.bgColor = FlxColor.TRANSPARENT;
		FlxG.cameras.add(widgetCam, false);

        // Widget Container
        widgetContainer = new FlxSpriteGroup();
		widgetContainer.cameras = [widgetCam];
        add(widgetContainer);

        // Widget Manager oluştur ve widget'ları başlat
        widgetManager = new WidgetManager(widgetContainer);
        widgetManager.initializeWidgets();

        // Music Player
        musicPlayer = new MusicPlayer();
        add(musicPlayer);

        // Widget Shop (en üstte olmalı)
        widgetShop = new WidgetShop();
        add(widgetShop);

        changeItem();

        #if ACHIEVEMENTS_ALLOWED
        var leDate = Date.now();
        if (leDate.getDay() == 5 && leDate.getHours() >= 18)
            Achievements.unlock('friday_night_play');

        #if MODS_ALLOWED
        Achievements.reloadList();
        #end
        #end

        #if CHECK_FOR_UPDATES
        if (showOutdatedWarning && ClientPrefs.data.checkForUpdates && substates.OutdatedSubState.updateVersion != psychEngineVersion)
        {
            persistentUpdate = false;
            showOutdatedWarning = false;
            openSubState(new substates.OutdatedSubState());
        }
        #end

        FlxG.camera.follow(camFollow, null, 0.15);
    }

    // Eksik fonksiyon eklendi
    function createMenuItem(name:String, x:Float, y:Float):FlxSprite
    {
        var menuItem:FlxSprite = new FlxSprite(x, y);
        menuItem.frames = Paths.getSparrowAtlas('mainmenu/menu_' + name);
        menuItem.animation.addByPrefix('idle', name + ' idle', 24, true);
        menuItem.animation.addByPrefix('selected', name + ' selected', 24, true);
        menuItem.animation.play('idle');
        menuItem.updateHitbox();
        menuItem.antialiasing = ClientPrefs.data.antialiasing;
        menuItem.scrollFactor.set();
        menuItems.add(menuItem);
        return menuItem;
    }

    override function update(elapsed:Float)
    {
        if (FlxG.sound.music != null && FlxG.sound.music.volume < 0.8)
            FlxG.sound.music.volume = Math.min(FlxG.sound.music.volume + 0.5 * elapsed, 0.8);

        // WidgetShop açıkken diğer inputları engelle
        if (WidgetShop.isOpen)
        {
            // ESC ile kapat
            if (FlxG.keys.justPressed.ESCAPE)
            {
                widgetShop.close();
            }
            
            super.update(elapsed);
            return;
        }

        // P tuşu ile shop aç (sadece kapalıyken)
        if (FlxG.keys.justPressed.P && !WorkspaceSwitcher.isOpen && !selectedSomethin)
        {
            widgetShop.open();
            super.update(elapsed);
            return;
        }

        if (!selectedSomethin)
            WorkspaceSwitcher.handleInput(elapsed);

        if (WorkspaceSwitcher.isOpen)
        {
            super.update(elapsed);
            return;
        }

        if (!selectedSomethin)
        {
            if (controls.UI_UP_P)
                changeItem(-1);

            if (controls.UI_DOWN_P)
                changeItem(1);

            var allowMouseLocal:Bool = allowMouse;
            if (allowMouseLocal && ((FlxG.mouse.deltaScreenX != 0 && FlxG.mouse.deltaScreenY != 0) || FlxG.mouse.justPressed))
            {
                allowMouseLocal = false;
                FlxG.mouse.visible = true;
                timeNotMoving = 0;

                var selectedItem:FlxSprite;
                switch(curColumn)
                {
                    case CENTER: selectedItem = menuItems.members[curSelected];
                    case LEFT: selectedItem = leftItem;
                    case RIGHT: selectedItem = rightItem;
                }

                if (leftItem != null && FlxG.mouse.overlaps(leftItem))
                {
                    allowMouseLocal = true;
                    if (selectedItem != leftItem)
                    {
                        curColumn = LEFT;
                        changeItem();
                    }
                }
                else if (rightItem != null && FlxG.mouse.overlaps(rightItem))
                {
                    allowMouseLocal = true;
                    if (selectedItem != rightItem)
                    {
                        curColumn = RIGHT;
                        changeItem();
                    }
                }
                else
                {
                    var dist:Float = -1;
                    var distItem:Int = -1;
                    for (i in 0...optionShit.length)
                    {
                        var memb:FlxSprite = menuItems.members[i];
                        if (FlxG.mouse.overlaps(memb))
                        {
                            var distance:Float = Math.sqrt(Math.pow(memb.getGraphicMidpoint().x - FlxG.mouse.screenX, 2) + Math.pow(memb.getGraphicMidpoint().y - FlxG.mouse.screenY, 2));
                            if (dist < 0 || distance < dist)
                            {
                                dist = distance;
                                distItem = i;
                                allowMouseLocal = true;
                            }
                        }
                    }

                    if (distItem != -1 && selectedItem != menuItems.members[distItem])
                    {
                        curColumn = CENTER;
                        curSelected = distItem;
                        changeItem();
                    }
                }
            }
            else
            {
                timeNotMoving += elapsed;
                if (timeNotMoving > 2) FlxG.mouse.visible = false;
            }

            switch(curColumn)
            {
                case CENTER:
                    if (controls.UI_LEFT_P && leftOption != null)
                    {
                        curColumn = LEFT;
                        changeItem();
                    }
                    else if (controls.UI_RIGHT_P && rightOption != null)
                    {
                        curColumn = RIGHT;
                        changeItem();
                    }

                case LEFT:
                    if (controls.UI_RIGHT_P)
                    {
                        curColumn = CENTER;
                        changeItem();
                    }

                case RIGHT:
                    if (controls.UI_LEFT_P)
                    {
                        curColumn = CENTER;
                        changeItem();
                    }
            }

            if (controls.BACK)
            {
                selectedSomethin = true;
                FlxG.mouse.visible = false;
                FlxG.sound.play(Paths.sound('cancelMenu'));
                ThemeManager.switchToTitle();
            }

            if (controls.ACCEPT || (FlxG.mouse.justPressed && allowMouseLocal))
            {
                FlxG.sound.play(Paths.sound('confirmMenu'));
                selectedSomethin = true;
                FlxG.mouse.visible = false;

                if (ClientPrefs.data.flashing)
                    FlxFlicker.flicker(magenta, 1.1, 0.15, false);

                var item:FlxSprite;
                var option:String;
                switch(curColumn)
                {
                    case CENTER:
                        option = optionShit[curSelected];
                        item = menuItems.members[curSelected];
                    case LEFT:
                        option = leftOption;
                        item = leftItem;
                    case RIGHT:
                        option = rightOption;
                        item = rightItem;
                }

                FlxFlicker.flicker(item, 1, 0.06, false, false, function(flick:FlxFlicker)
                {
                    switch (option)
                    {
                        case 'story_mode':
                            MusicBeatState.switchState(new StoryMenuState());
                        case 'freeplay':
                            MusicBeatState.switchState(new FreeplayState());
                        #if MODS_ALLOWED
                        case 'mods':
                            MusicBeatState.switchState(new ModsMenuState());
                        #end
                        #if ACHIEVEMENTS_ALLOWED
                        case 'achievements':
                            MusicBeatState.switchState(new AchievementsMenuState());
                        #end
                        case 'credits':
                            MusicBeatState.switchState(new CreditsState());
                        case 'options':
                            MusicBeatState.switchState(new OptionsState());
                            OptionsState.onPlayState = false;
                            if (PlayState.SONG != null)
                            {
                                PlayState.SONG.arrowSkin = null;
                                PlayState.SONG.splashSkin = null;
                                PlayState.stageUI = 'normal';
                            }
                        case 'donate':
                            CoolUtil.browserLoad('https://ninja-muffin24.itch.io/funkin');
                            selectedSomethin = false;
                            item.visible = true;
                        default:
                            trace('Menu Item ' + option + ' doesn\'t do anything');
                            selectedSomethin = false;
                            item.visible = true;
                    }
                });

                for (memb in menuItems)
                {
                    if (memb == item)
                        continue;
                    FlxTween.tween(memb, {alpha: 0}, 0.4, {ease: FlxEase.quadOut});
                }
            }

            #if desktop
            if (controls.justPressed('debug_1'))
            {
                selectedSomethin = true;
                FlxG.mouse.visible = false;
                MusicBeatState.switchState(new MasterEditorMenu());
            }
            #end
        }

        super.update(elapsed);
    }

    function changeItem(change:Int = 0)
    {
        if (change != 0) curColumn = CENTER;
        curSelected = FlxMath.wrap(curSelected + change, 0, optionShit.length - 1);
        FlxG.sound.play(Paths.sound('scrollMenu'));

        for (item in menuItems)
        {
            item.animation.play('idle');
            item.centerOffsets();
        }

        var selectedItem:FlxSprite;
        switch(curColumn)
        {
            case CENTER: selectedItem = menuItems.members[curSelected];
            case LEFT: selectedItem = leftItem;
            case RIGHT: selectedItem = rightItem;
        }
        selectedItem.animation.play('selected');
        selectedItem.centerOffsets();
        camFollow.y = selectedItem.getGraphicMidpoint().y;
    }

    override function destroy()
    {
        if (WorkspaceSwitcher.isOpen)
            WorkspaceSwitcher.forceClose();
        
        if (WidgetShop.isOpen)
            widgetShop.close();
        
        if (widgetManager != null)
            widgetManager.destroy();
        
        WidgetBase.resetDragState();

        super.destroy();
    }
}